# No custom rules required for the test build.
