package com.dtstudio.beauty;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.InputStream;

public class MainActivity extends Activity {
    private LinearLayout root;
    private final int PURPLE = Color.rgb(181, 77, 232);
    private final int DARK = Color.rgb(81, 29, 105);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(124,50,180));
        getWindow().setNavigationBarColor(Color.rgb(40,19,47));
        showSplash();
    }

    private void showSplash() {
        ImageView splash = new ImageView(this);
        splash.setImageResource(R.drawable.splash);
        splash.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setContentView(splash);
        new Handler().postDelayed(this::showHome, 900);
    }

    private void showHome() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(18), dp(20), dp(18), dp(18));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(255,214,244), PURPLE, DARK});
        root.setBackground(bg);

        TextView title = text("DT STUDIO BEAUTY", 28, Color.WHITE);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(70)));

        TextView sub = text("Escolha uma experiência", 15, Color.WHITE);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(35)));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setGravity(Gravity.CENTER);
        addButton(grid, "MAKE UP", "assets/makeUp/backGround.png");
        addButton(grid, "WASH HAIR", "assets/washHair/bg.png");
        addButton(grid, "DRESS UP", "assets/dressUp/bg.png");
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("Android 5.0+ • APK universal • sem bibliotecas nativas", 12, Color.WHITE);
        root.addView(footer, new LinearLayout.LayoutParams(-1, dp(34)));
        setContentView(root);
    }

    private void addButton(LinearLayout parent, String label, String asset) {
        TextView b = text(label, 20, Color.WHITE);
        b.setTypeface(null, 1);
        b.setBackground(round(Color.argb(220, 181,77,232), dp(22)));
        b.setOnClickListener(v -> showScene(label, asset));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(285), dp(68));
        p.setMargins(0, dp(8), 0, dp(8));
        parent.addView(b, p);
    }

    private void showScene(String name, String asset) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(255,215,245));

        TextView bar = text(name, 21, Color.WHITE);
        bar.setTypeface(null, 1);
        bar.setBackgroundColor(PURPLE);
        page.addView(bar, new LinearLayout.LayoutParams(-1, dp(58)));

        ImageView scene = new ImageView(this);
        scene.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try (InputStream in = getAssets().open(asset)) {
            scene.setImageBitmap(android.graphics.BitmapFactory.decodeStream(in));
        } catch (Exception e) {
            scene.setBackgroundColor(Color.rgb(255,190,230));
        }
        page.addView(scene, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView back = text("‹  VOLTAR", 18, Color.WHITE);
        back.setBackgroundColor(Color.rgb(126,50,180));
        back.setOnClickListener(v -> showHome());
        page.addView(back, new LinearLayout.LayoutParams(-1, dp(62)));
        setContentView(page);
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        return t;
    }
    private GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
