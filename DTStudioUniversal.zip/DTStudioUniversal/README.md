# DT Studio Universal

Reconstrução limpa baseada no APK fornecido pelo usuário.

## Objetivo
APK Java-only para evitar a dependência da biblioteca nativa 32-bit do APK original. Isso permite um único APK para ARM, ARM64, x86 e x86_64, mantendo `minSdk 21`.

## Build
- Android Gradle Plugin 8.7.3
- compileSdk 36
- targetSdk 36
- minSdk 21

### APK de teste
No GitHub Actions, execute `Build APK` e baixe o artefato `dtstudio-universal-debug`.

O APK de debug é assinado automaticamente e serve para instalação direta em aparelhos de teste.
